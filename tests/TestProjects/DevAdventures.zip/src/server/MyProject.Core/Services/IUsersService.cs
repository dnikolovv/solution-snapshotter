﻿using System.Threading.Tasks;
using MyProject.Core.Models;
using Optional;

namespace MyProject.Core.Services
{
    public interface IUsersService
    {
        Task<Option<JwtModel, Error>> Login(LoginUserModel model);

        Task<Option<UserModel, Error>> Register(RegisterUserModel model);
    }
}
