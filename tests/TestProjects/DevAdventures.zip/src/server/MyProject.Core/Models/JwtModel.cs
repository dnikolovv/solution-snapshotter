﻿namespace MyProject.Core.Models
{
    public class JwtModel
    {
        public string TokenString { get; set; }
    }
}
