using System.Linq;

namespace $safeprojectname$.Structure
{
    public class StructureConfiguration
    {
        public ProjectInfo[] Projects { get; set; } = Enumerable.Empty<ProjectInfo>().ToArray();

        public ExtraFolderMapping[] ExtraFolders { get; set; } = Enumerable.Empty<ExtraFolderMapping>().ToArray();

        public SolutionFolderStructure SolutionFolderStructure { get; set; }
    }
}
