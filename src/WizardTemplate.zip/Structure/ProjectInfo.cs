namespace $safeprojectname$.Structure
{
    public class ProjectInfo
    {
        public string SafeProjectName { get; set; }

        public string DestinationDirectory { get; set; }

        public string DestinationSolutionDirectory { get; set; }

        public string ProjectFileExtension { get; set; }
    }
}
