namespace $safeprojectname$.Structure
{
    public class SolutionFolderStructure
    {
        public SolutionFolderNode[] Nodes { get; set; }
    }
}
