using System.Linq;

namespace $safeprojectname$.Structure
{
    public class SolutionFolderNode
    {
        public string FullPath { get; set; }

        public string Name { get; set; }

        public SolutionFolderNode[] Children { get; set; } = Enumerable.Empty<SolutionFolderNode>().ToArray();
    }
}
