﻿using EnvDTE;
using EnvDTE100;
using EnvDTE80;
using Microsoft.VisualStudio.TemplateWizard;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using $safeprojectname$.Structure;

namespace $safeprojectname$
{
    public class Wizard : IWizard
    {
        private string _originalDestinationDirectory;
        private string _safeProjectName;
        private Solution4 _solution;

        // This method is called before opening any item that
        // has the OpenInEditor attribute.
        public void BeforeOpeningFile(ProjectItem projectItem)
        {
        }

        public void ProjectFinishedGenerating(Project project)
        {
        }

        // This method is only called for item templates
        // not for project templates.
        public void ProjectItemFinishedGenerating(ProjectItem projectItem)
        {
        }

        // This method is called after the project is created
        public void RunFinished()
        {
            var templateContentsPath = Path.Combine(
                Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location),
                @"ProjectTemplates\Template");

            var templateDirectory = new DirectoryInfo(templateContentsPath);

            var structureFile = templateDirectory
                .GetFiles("structure.json")[0];

            using (var structureFileStream = structureFile.OpenRead())
            using (var structureFileReader = new StreamReader(structureFileStream))
            {
                var structureFileString = structureFileReader.ReadToEnd();
                var structure = JsonConvert.DeserializeObject<StructureConfiguration>(structureFileString);

                var rootProjectFolder = Directory.GetParent(_originalDestinationDirectory).FullName;

                // We need to use a unique temp folder to avoid name conflicts
                var tempFolderName = $"temp-{Guid.NewGuid().ToString().Substring(0, 3)}";
                var tempRootProjectFolder = Path.Combine(
                    rootProjectFolder,
                    tempFolderName);

                AddExtraFolders(structure, templateDirectory.GetDirectories(), tempRootProjectFolder);
                var projectsInfo = MoveProjectsToCorrespondingFolders(structure, tempRootProjectFolder);

                // It should now be empty anyways since we expect the projects to have moved
                Directory.Delete(_originalDestinationDirectory);

                // After moving the projects from temp we need to update the .*sproj paths
                var updatedProjectsInfo = MoveProjectOutOfTempFolder(
                    rootProjectFolder,
                    tempFolderName,
                    tempRootProjectFolder,
                    projectsInfo);

                MoveProjectsToDestinationSolutionFolders(structure, updatedProjectsInfo);
            }
        }

        private static List<(string projFilePath, string destinationSolutionFolder)> MoveProjectOutOfTempFolder(
            string rootProjectFolder,
            string tempFolderName,
            string tempRootProjectFolder,
            List<(string projFilePath, string destinationSolutionFolder)> projectsInfo)
        {
            MoveContentsOfDirectory(tempRootProjectFolder, rootProjectFolder);

            // After moving the projects from temp we need to update the .*sproj paths
            var updatedProjectsInfo = projectsInfo
                .Select(pair =>
                {
                    pair.projFilePath = pair.projFilePath.Replace($"{tempFolderName}\\", string.Empty);
                    return pair;
                })
                .ToList();

            return updatedProjectsInfo;
        }

        private void MoveProjectsToDestinationSolutionFolders(StructureConfiguration structure, List<(string projFilePath, string destinationSolutionFolder)> projectsInfo)
        {
            var solutionFoldersMapping = CreateFoldersRecursively(structure.SolutionFolderStructure.Nodes);

            foreach (var (projFilePath, destinationSolutionFolder) in projectsInfo)
            {
                if (string.IsNullOrEmpty(destinationSolutionFolder))
                {
                    _solution.AddFromFile(projFilePath, false);
                }
                else
                {
                    var solutionFolder = solutionFoldersMapping[destinationSolutionFolder];
                    solutionFolder.AddFromFile(projFilePath);
                }
            }
        }

        public void RunStarted(object automationObject, Dictionary<string, string> replacementsDictionary, WizardRunKind runKind, object[] customParams)
        {
            _safeProjectName = replacementsDictionary["$safeprojectname$"];
            _originalDestinationDirectory = replacementsDictionary["$destinationdirectory$"];
            _solution = ((automationObject as DTE2).Solution as Solution4);
        }

        // This method is only called for item templates,
        // not for project templates.
        public bool ShouldAddProjectItem(string filePath)
        {
            return true;
        }

        private void AddExtraFolders(StructureConfiguration structure, DirectoryInfo[] templateDirectories, string rootProjectFolder)
        {
            foreach (var extraFolder in structure.ExtraFolders)
            {
                var extraFolderDestination = Path.Combine(
                    rootProjectFolder,
                    extraFolder.FolderPath.TrimStart('\\'));

                Directory.CreateDirectory(extraFolderDestination);

                var contents = templateDirectories
                    .First(d => d.Name == extraFolder.ContentPath)
                    .GetFiles();

                foreach (var file in contents)
                {
                    file.CopyTo(Path.Combine(extraFolderDestination, file.Name));
                }
            }
        }

        /// <summary>
        /// We need to create a backup of the original generated .*sproj
        /// because the call to solution.Remove will remove references that we will need
        /// </summary>
        private static (string projFileName, string backupProjFileName) CreateBackupProjFile(string projectName, string projectFolderPath, string projFileExtension)
        {
            // We need to create a backup of the original generated .*sproj
            // because the call to solution.Remove will remove references that we will need
            var projFileName = $"{projectName}{projFileExtension}";

            var originalProjFilePath = Path.Combine(
                projectFolderPath,
                projFileName);

            var backupProjFileName = $"{projFileName}.BACKUP";

            File.Copy(originalProjFilePath, Path.Combine(projectFolderPath, backupProjFileName));

            return (projFileName, backupProjFileName);
        }

        private List<(string projFilePath, string destinationSolutionFolder)> MoveProjectsToCorrespondingFolders(
            StructureConfiguration structure,
            string tempRootProjectFolder)
        {
            var projectsInfo = structure
                .Projects
                .Select(projectInfo =>
                {
                    var projectName = projectInfo.SafeProjectName.Replace("$safeprojectname$", _safeProjectName);

                    var projectFolderPath = Path.Combine(_originalDestinationDirectory, projectName);

                    var (projFileName, backupProjFileName) = CreateBackupProjFile(projectName, projectFolderPath, projectInfo.ProjectFileExtension);

                    var project = _solution.GetProject(projectName);
                    _solution.Remove(project);

                    var projectDestinationRoot = Path.GetFullPath(Path.Combine(
                        tempRootProjectFolder,
                        projectInfo.DestinationDirectory.TrimStart('\\')));

                    Directory.CreateDirectory(projectDestinationRoot);

                    var projectDestinationFull = Path.Combine(projectDestinationRoot, projectName);

                    Directory.Move(projectFolderPath, projectDestinationFull);

                    var projFilePath = Path.Combine(projectDestinationFull, projFileName);

                    File.Delete(projFilePath);

                    // Rename the backup back to the original
                    File.Move(Path.Combine(projectDestinationFull, backupProjFileName), projFilePath);

                    return (projFilePath, projectInfo.DestinationSolutionDirectory);
                })
                .ToList();

            return projectsInfo;
        }

        /// <summary>
        /// Courtesy of https://stackoverflow.com/questions/6800649/how-to-move-file-folder-to-an-already-existing-folder
        /// </summary>
        private static void MoveContentsOfDirectory(string source, string target)
        {
            foreach (var file in Directory.EnumerateFiles(source))
            {
                var dest = Path.Combine(target, Path.GetFileName(file));
                File.Move(file, dest);
            }

            foreach (var dir in Directory.EnumerateDirectories(source))
            {
                var dest = Path.Combine(target, Path.GetFileName(dir));
                Directory.Move(dir, dest);
            }

            // optional
            Directory.Delete(source);
        }

        private Dictionary<string, SolutionFolder> CreateFoldersRecursively(SolutionFolderNode[] nodes) =>
            nodes
                .Select(CreateFoldersRecursively)
                .SelectMany(mappings => mappings)
                .ToDictionary(pair => pair.Key, pair => pair.Value);

        private Dictionary<string, SolutionFolder> CreateFoldersRecursively(SolutionFolderNode root) =>
            CreateFoldersRecursively(root, new Dictionary<string, SolutionFolder>());

        private Dictionary<string, SolutionFolder> CreateFoldersRecursively(SolutionFolderNode node, Dictionary<string, SolutionFolder> folders, SolutionFolder parent = null)
        {
            SolutionFolder current;

            if (!folders.ContainsKey(node.FullPath))
            {
                current = parent == null ?
                    _solution.AddSolutionFolderEx(node.Name) :
                    (SolutionFolder)parent.AddSolutionFolder(node.Name).Object;

                folders.Add(node.FullPath, current);
            }
            else
            {
                current = folders[node.FullPath];
            }

            foreach (var child in node.Children)
            {
                CreateFoldersRecursively(child, folders, current);
            }

            return folders;
        }
    }
}
