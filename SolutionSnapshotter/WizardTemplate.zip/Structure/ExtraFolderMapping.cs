namespace $safeprojectname$.Structure
{
    public class ExtraFolderMapping
    {
        public string FolderPath { get; set; }

        public string ContentPath { get; set; }
    }
}
